"""Custom Lambda function"""

import json
import logging
import boto3
import datetime

now = datetime.datetime.now()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def write2dynamo(context):
    messagevalue = ''
    dynamodb_resource = boto3.resource('dynamodb')
    dynamodb_client = boto3.client('dynamodb')
    data_table = dynamodb_resource.Table('TrainingTable')
    logger.info('REQUEST RECEIVED:\n %s', event)
    logger.info('REQUEST RECEIVED:\n %s', context)
    if event['RequestType'] == 'Create':
            logger.info('CREATE!')
            messagevalue = 'Create stack'
        elif event['RequestType'] == 'Update':
            logger.info('UPDATE!')
            messagevalue = 'Update stack'
        elif event['RequestType'] == 'Delete':
            logger.info('DELETE!')
            messagevalue = 'Delete stack'
        else:
            logger.info('FAILED!')
            messagevalue = 'Operation on stack failed'
    except: 
        logger.info('Problem! Function execution failed')
    try:
        data_table.put_item(
            Item={
                'Element': messagevalue,
                'ElementValue': now.isoformat
            }
        )
        except dynamodb_client.exceptions.ClientError as error:
            msg = "Something wrong with my table!"
            print(error)
            return {"msg": msg}
    return 0
